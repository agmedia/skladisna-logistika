<template>
    <div>
        <div v-if="$store.state.cart.count" id="content" class="col-sm-12">
            <table class="table table-bordered border-bottom">
                <thead>
                <tr>
                    <td class="hidden-xs hidden-sm"></td>
                    <td colspan="2">Naziv artikla</td>
                    <td class="hidden-xs hidden-sm">Model</td>
                    <td>Količina</td>
                    <td class="text-right hidden-xs hidden-sm">Cijena</td>
                    <td class="text-right">Ukupno</td>
                    <td></td>
                </tr>
                </thead>

                <tbody>
                <tr v-for="item in $store.state.cart.items">
                    <td class="remove-cell hidden-xs hidden-sm text-center">
                        <a @click.prevent="removeFromCart(item)" data-toggle="tooltip" title="Ukloni" class="product-remove"><i class="fa fa-times"></i></a>
                    </td>
                    <td class="image">
                        <a :href="item.attributes.url + item.associatedModel.slug">
                            <img :src="item.associatedModel.image" :alt="item.name" :title="item.name" width="100"/>
                        </a>
                    </td>
                    <td class="name">
                        <a class="hover_uline" :href="item.attributes.url + item.associatedModel.slug">{{ item.name }}</a>
                        <small class="hidden-md hidden-lg"><br />Model: {{ item.sku }}</small>
                        <small class="hidden-md hidden-lg"><br />Cijena: {{ item.price ? Number(item.price).toFixed(2) : item.price }}kn</small><br />
                        <a class="btn btn-default btn-tiny hidden-md hidden-lg" style="margin-top:5px;" @click.prevent="removeFromCart(item)">Ukloni</a>
                    </td>
                    <td class="hidden-xs hidden-sm">{{ item.sku }}</td>
                    <td>
                        <input type="number" min="1" step="1" v-model="item.quantity" class="form-control qty-form" />
                    </td>
                    <td class="text-right price-cell hidden-xs hidden-sm">{{ item.price ? Number(item.price).toFixed(2) : item.price }}kn</td>
                    <td class="text-right total-cell">{{ item.price ? Number(item.price * item.quantity).toFixed(2) : item.price * item.quantity }}kn</td>
                    <td>
                        <button @click.prevent="recalculateCart(item)" class="btn btn-default"><i class="fa fa-refresh"></i></button>
                    </td>
                </tr>

                </tbody>

            </table>
            <div class="row margin-b30">
                <div class="col-xs-12 text-right">
                    <a v-if="buttons" :href="continueurl" class="btn btn-warning"><i class="fa fa-angle-left"></i> Nazad na Trgovinu</a>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-7">
                </div>
                <div class="col-sm-5">
                    <div class="totals-slip">
                        <div class="table-holder margin-b25">
                            <table class="table table-bordered total-list margin-b0">
                                <tr>
                                    <td><b>Među suma:</b></td>
                                    <td class="text-right">{{ $store.state.cart.subtotal ? Number($store.state.cart.subtotal).toFixed(2) : $store.state.cart.subtotal }}kn</td>
                                </tr>
                                <tr>
                                    <td><b>Poštarina:</b></td>
                                    <td class="text-right">{{ $store.state.cart.shipping_total ? Number($store.state.cart.shipping_total).toFixed(2) : '0.00' }}kn</td>
                                </tr>
                                <tr>
                                    <td><b>Ukupno:</b></td>
                                    <td class="text-right">{{ $store.state.cart.subtotal ? Number($store.state.cart.subtotal + $store.state.cart.shipping_total).toFixed(2) : $store.state.cart.subtotal + $store.state.cart.shipping_total }}kn</td>
                                </tr>
                            </table>
                        </div>
                        <a v-if="buttons" :href="checkouturl" class="btn btn-lg btn-contrast btn-block">Plaćanje <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div v-else class="b-cart b-cart_empty">
            <div class="text-center">
                <i class="icon-basket icons"></i>
                <h2><b>VAŠA KOŠARICA JE TRENUTNO PRAZNA.</b></h2>
                <p>
                    Prije nego odete na Checkout morate staviti nešto u košaricu.
                    <br>Naći ćete puno različitih stvari u našoj trgovini.
                </p>
                <a href="/" class="btn">Nazad na Trgovinu</a>
            </div>
        </div>
        <input type="hidden" name="order_data" :value="JSON.stringify($store.state.cart)">
    </div>
</template>

<script>
    export default {
        props: {
            continueurl: String,
            checkouturl: String,
            buttons: {type: Boolean, default: true},
        },

        mounted() {

        },

        methods: {
            recalculateCart(item) {
                this.$store.dispatch('updateCart', item);
            },

            removeFromCart(item) {
                this.$store.dispatch('removeItem', item);
            },

            CheckQuantity(qty) {
                if (qty < 1) {
                    return 1;
                }

                return qty;
            }
        }
    };
</script>

<template>
    <div class="icon-element catalog_hide">
        <div id="cart" class="dropdown-wrapper from-top">
            <a :href="carturl" class="shortcut-wrapper cart">
                <i id="cart-icon" class="global-cart icon"></i>
                <span id="cart-total" class="nowrap">
                    <span class="counter cart-total-items">{{ $store.state.cart.count ? $store.state.cart.count : 0 }}</span>
                    <span class="slash hidden-md hidden-sm hidden-xs">/</span>
                    <b class="cart-total-amount hidden-sm hidden-xs">{{ $store.state.cart.subtotal ? Number($store.state.cart.subtotal).toFixed(2) : 0 }}kn</b>
                </span>
            </a>
            <!-- Full Cart -->
            <div v-if="$store.state.cart.count" class="dropdown-content dropdown-right hidden-sm hidden-xs">
                <ul id="cart-content">
                    <li>
                        <table class="table products">
                            <tbody>
                            <tr v-for="item in $store.state.cart.items">
                                <td class="image">
                                    <a href="#"><img :src="base_path + item.associatedModel.image" :alt="item.name" :title="item.name"></a>
                                </td>
                                <td class="main"><a class="product-name main-font" href="#">{{ item.name }}</a>
                                    {{ item.quantity }} x <span class="price">{{ item.price ? Number(item.price).toFixed(2) : item.price }}kn</span>
                                </td>
                                <td class="remove"><a @click.prevent="removeFromCart(item)" title="Ukloni" class="remove">×</a></td>
                            </tr>
                            </tbody>
                        </table>
                    </li>
                    <li>
                        <div>
                            <table class="table totals">
                                <tbody>
                                <tr>
                                    <td class="text-left">Među suma</td>
                                    <td class="text-right">{{ $store.state.cart.subtotal ? Number($store.state.cart.subtotal).toFixed(2) : $store.state.cart.subtotal }}kn</td>
                                </tr>
                                <tr>
                                    <td class="text-left">Ukupno</td>
                                    <td class="text-right">{{ $store.state.cart.total ? Number($store.state.cart.total).toFixed(2) : $store.state.cart.total }}kn</td>
                                </tr>
                                </tbody>
                            </table>
                            <a class="btn btn-default btn-block" :href="carturl">Pogledajte košaricu</a>
                            <a class="btn btn-contrast btn-block" :href="checkouturl">Naplata</a>
                        </div>
                    </li>
                </ul>
            </div>
            <!-- Empty Cart -->
            <div v-else class="dropdown-content dropdown-right hidden-sm hidden-xs">
                <ul id="cart-content">
                    <li>
                        <div class="table empty">
                            <div class="table-cell"><i class="global-cart"></i></div>
                            <div class="table-cell">Vaša košarica je prazna!!</div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>


</template>

<script>
    export default {
        props: {
            carturl: String,
            checkouturl: String,
        },
        //
        data() {
            return {
                base_path: window.location.origin + '/',
                success_path: window.location.origin + '/kosarica/success'
            }
        },
        //
        mounted() {
            this.getCart();

            if (window.location.pathname == '/kosarica/success') {
                this.$store.dispatch('flushCart');
            }
        },
        //
        methods: {
            //
            getCart() {
                this.$store.dispatch('getUser').then(response => {
                    console.log('getUser() Response : : : ', response);
                    this.$store.dispatch('getCart')
                })
            },
            //
            removeFromCart(item) {
                this.$store.dispatch('removeItem', item);
            }
        }
    };
</script>
